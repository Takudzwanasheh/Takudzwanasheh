import React from 'react';

function Privacy (){
    return 
}

export default Privacy;